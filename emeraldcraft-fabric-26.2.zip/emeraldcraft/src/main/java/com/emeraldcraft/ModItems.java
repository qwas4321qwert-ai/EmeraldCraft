package com.emeraldcraft;

import java.util.function.Function;

import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.equipment.ArmorType;

public final class ModItems {
	private ModItems() {
	}

	// ---------- Броня ----------
	public static final Item EMERALD_HELMET = register("emerald_helmet", Item::new, armor(ArmorType.HELMET));
	public static final Item EMERALD_CHESTPLATE = register("emerald_chestplate", Item::new, armor(ArmorType.CHESTPLATE));
	public static final Item EMERALD_LEGGINGS = register("emerald_leggings", Item::new, armor(ArmorType.LEGGINGS));
	public static final Item EMERALD_BOOTS = register("emerald_boots", Item::new, armor(ArmorType.BOOTS));

	// ---------- Инструменты ----------
	public static final Item EMERALD_SWORD = register("emerald_sword", Item::new,
			new Item.Properties().sword(EmeraldMaterials.TOOL, 3.0F, -2.4F));
	public static final Item EMERALD_PICKAXE = register("emerald_pickaxe", Item::new,
			new Item.Properties().pickaxe(EmeraldMaterials.TOOL, 1.0F, -2.8F));
	public static final Item EMERALD_AXE = register("emerald_axe",
			props -> new AxeItem(EmeraldMaterials.TOOL, 5.0F, -3.0F, props), new Item.Properties());
	public static final Item EMERALD_SHOVEL = register("emerald_shovel",
			props -> new ShovelItem(EmeraldMaterials.TOOL, 1.5F, -3.0F, props), new Item.Properties());
	public static final Item EMERALD_HOE = register("emerald_hoe",
			props -> new HoeItem(EmeraldMaterials.TOOL, -3.0F, 0.0F, props), new Item.Properties());

	private static Item.Properties armor(ArmorType type) {
		return new Item.Properties()
				.humanoidArmor(EmeraldMaterials.ARMOR, type)
				.durability(type.getDurability(EmeraldMaterials.ARMOR_BASE_DURABILITY));
	}

	private static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties properties) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, EmeraldCraft.id(name));
		Item item = factory.apply(properties.setId(key));
		return Registry.register(BuiltInRegistries.ITEM, key, item);
	}

	public static void initialize() {
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(tab -> {
			tab.accept(EMERALD_SWORD);
			tab.accept(EMERALD_AXE);
			tab.accept(EMERALD_HELMET);
			tab.accept(EMERALD_CHESTPLATE);
			tab.accept(EMERALD_LEGGINGS);
			tab.accept(EMERALD_BOOTS);
		});

		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(tab -> {
			tab.accept(EMERALD_SHOVEL);
			tab.accept(EMERALD_PICKAXE);
			tab.accept(EMERALD_AXE);
			tab.accept(EMERALD_HOE);
		});
	}
}
