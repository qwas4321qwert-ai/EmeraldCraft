package com.emeraldcraft;

import java.util.Map;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.level.block.Block;

public final class EmeraldMaterials {
	private EmeraldMaterials() {
	}

	/** Чем чинить в наковальне: изумруд (data/emeraldcraft/tags/item/repairs_emerald_equipment.json). */
	public static final TagKey<Item> REPAIRS_EMERALD_EQUIPMENT =
			TagKey.create(Registries.ITEM, EmeraldCraft.id("repairs_emerald_equipment"));

	/** Блоки, которые инструмент НЕ может добыть (data/emeraldcraft/tags/block/incorrect_for_emerald_tool.json). */
	public static final TagKey<Block> INCORRECT_FOR_EMERALD_TOOL =
			TagKey.create(Registries.BLOCK, EmeraldCraft.id("incorrect_for_emerald_tool"));

	// ---------- Броня ----------
	/** Множитель прочности (железо 15, алмаз 33, незерит 37). */
	public static final int ARMOR_BASE_DURABILITY = 28;

	/** Ключ equipment-ассета: assets/emeraldcraft/equipment/emerald.json */
	public static final ResourceKey<EquipmentAsset> ARMOR_ASSET =
			ResourceKey.create(EquipmentAssets.ROOT_ID, EmeraldCraft.id("emerald"));

	public static final ArmorMaterial ARMOR = new ArmorMaterial(
			ARMOR_BASE_DURABILITY,
			Map.of(
					ArmorType.HELMET, 3,
					ArmorType.CHESTPLATE, 7,
					ArmorType.LEGGINGS, 6,
					ArmorType.BOOTS, 3
			),
			18, // зачаровываемость
			SoundEvents.ARMOR_EQUIP_DIAMOND,
			1.0F, // твёрдость (toughness)
			0.0F, // сопротивление отбрасыванию
			REPAIRS_EMERALD_EQUIPMENT,
			ARMOR_ASSET
	);

	// ---------- Инструменты ----------
	public static final ToolMaterial TOOL = new ToolMaterial(
			INCORRECT_FOR_EMERALD_TOOL,
			1000, // прочность (алмаз 1561, железо 250)
			7.5F, // скорость добычи
			2.5F, // бонус к урону
			18, // зачаровываемость
			REPAIRS_EMERALD_EQUIPMENT
	);
}
