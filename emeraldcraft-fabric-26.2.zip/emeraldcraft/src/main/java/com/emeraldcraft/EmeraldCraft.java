package com.emeraldcraft;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

public class EmeraldCraft implements ModInitializer {
	public static final String MOD_ID = "emeraldcraft";

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModItems.initialize();
	}
}
